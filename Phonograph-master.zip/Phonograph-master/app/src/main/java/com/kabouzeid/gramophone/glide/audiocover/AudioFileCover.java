package com.kabouzeid.gramophone.glide.audiocover;

/**
 * @author Karim Abou Zeid (kabouzeid)
 */
public class AudioFileCover {
    public final String filePath;

    public AudioFileCover(String filePath) {
        this.filePath = filePath;
    }
}
